---
type: media
title: "Intelligence is Immanent"
slug: intelligence-is-immanent-edition
date: 2026-11-25
summary: "A process model on the becoming of minds, intelligence and knowledge, aligning with Weaver Weinbaum's theory of open-ended intelligence to ask what it means to become intelligent."
edition_of: intelligence-is-immanent
formats:
  - "epub"
  - "pdf"
  - "md"
---
