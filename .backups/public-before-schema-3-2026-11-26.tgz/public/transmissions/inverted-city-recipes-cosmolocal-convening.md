---
type: transmission
title: "Recipes- Cosmolocal Convening"
slug: inverted-city-recipes-cosmolocal-convening
date: 2025-02-28
summary: "A recipe and detailed case study for organizing a cosmolocal convening that brings together hyperlocal and globally distributed participants, including planning logistics, funding strategies, and a firsthand account of the General Forum on Ethereum Localism held in Portland in October 2023."
tags:
  - "theme/distributed-agency"
  - "theme/consent-coordination"
author:
  - "christypdx"
collection: inverted-city
---

# Recipes: Cosmolocal Convening

*by christypdx*

Bringing together a regional and global consortium of passionate individuals who are working, individually and together, in pursuit of a shared vision can and very likely will be generative in both planned and unexpected ways.

## Ingredients

- **Shared context** — Have clearly articulated and agreed upon the purpose, audience and content-focus, and desired outcomes of the convening. Share a big picture vision. Cosmolocal: Radical local initiatives reflect the global: makerspaces reflect very cosmopolitan knowledge share, permaculture is an extremely cosmopolitan knowledge set.
- **A strong network of aligned (and probably geographically hyperlocal) individuals** who will need to act as the event planning team. A proven ability to work together effectively both synchronously and asynchronously is helpful, but may not be necessary.
- **An identified and known geographically distributed network of aligned individuals** who might be available to travel to your city to attend a multi-day gathering. Who you convene is as important as why you convene, and mixing local with non-local perspectives is productive.
- **A venue suited for the collaborative nature of this type of gathering.** Prioritize space that will allow for the whole group to gather, and break into smaller sessions. A projector, screen and basic audio setup should be available. If you have access to a community space that's reflective of the diversity of your locality, that's an ideal venue.
- **Some amount of funding** - though your budget may be limited. If you don't have a lot of funding to play with, you'll need to get creative, and perform much or all of your work as an unpaid volunteer. That's ok. If you truly believe that a convening is worth facilitating, make it happen (all magic comes at a cost). If it goes well, mint an event hypercert, and apply for retroactive funding.
- **An eye toward synchronicities and an appreciation for the magic of everyday existence.**

## Instructions

Kick off planning! Set a regular schedule for meeting, and expect/plan to meet increasingly more often as the event date approaches. Hold yourself and one other accountable for following through with commitments.

Set a date as early as possible. Take into consideration conflicting events of your attendees, and, in our case (more on that later), likely weather conditions. When you have the date, start building the event schedule in a shared planner/spreadsheet, and keep it up to date.

Determine communication channels and commitment levels from contributors. Maintaining an open communication channel that planners commit to using will go a long way in minimizing duplicate work, etc.

Think through event logistics, down to the smallest details (if you're hosting at a community space, will there be enough toilet paper?), and have your various plan Bs in mind. Keep good documentation: notes, schedules, receipts, etc. Make sure contributors have access to the programs and materials their work requires. When planning out the event timeline and content, remain flexible and don't be afraid of radical changes.

**Optional:** Decide on a ticketing platform. There are already many great options to choose from when it comes to web3 event ticketing. Choosing to offer a web3 ticket to attendees brings your event onchain, generates a keepsake NFT for participants, and benefits the evolution of the tech.

Find out how your community members want to contribute, what skills they have that your event needs. If you ask for volunteers you'll find them—be clear about event needs with the community so that people know how they can help.

## Account: A General Forum on Ethereum Localism, October 2023 — Portland, OR

In October 2023 PDX DAO put on the General Forum on Ethereum Localism (GFEL) in Portland, OR as a convening of 50+ web3 natives (and a handful of non-natives) thinking about and experimenting with onchain localism, i.e. the possibility of using DAOs to develop novel decentralized community/city/bioregional systems and infrastructure (maker space cooperatives, community currencies, small business coalitions, credit clearing circles, etc.); building mechanisms to bring p2p and ownership economies to local scale (neighbourhoods).

PDX DAO's relationships with a variety of local people, projects and places that embody the spirit of decentralization and community autonomy allowed for a meaningful offering of pre-conference tours and micro-events - at urban farms, an intentional permaculture community, makerspaces and art collectives. Incorporating events that connected people with our city and its decentralized protocols was a critical design element, in aiming to materialize the cosmo-local frame of reference. The Forum was preceded by two days of these tours.

The Forum itself was a three-day event, a structured unconference, hosted at a community warehouse in Portland's Inner Eastside. The warehouse space could be set up to accommodate whole-group speaking and panel sessions or several breakout groups. We had a solid A/V setup (we even enjoyed live music one evening), a chill zone with couches, morning yoga and catered lunch each day as an incentive for participants to stay convened throughout the course of the day. It worked!

Many attendees stuck around post-forum, and, over the next few days re-convened for a variety of activities - coffee meetups, mushroom foraging, co-working, dinner, drinks. Existing networks had been strengthened and expanded, and an abundance of new networks had been activated (an output of one of which you read from now).

The convening was a success because we, a hyperlocal group of dedicated co-conspirators, had been working on the same problem and asking the same questions as a global consortium of both localized and distributed peers. Critically, we were fortunate to benefit from a reliable network of aligned and supportive individuals, both locally and globally, who offered invaluable resources - including and especially Bridge Space Commons, our main event venue - and skillshares (key to this network was a year's work of passionate network weaving). To cover event costs, we received direct donations and matching funds from two Gitcoin grant rounds, applied for and received a grant from MetaCartel's ETHos, and received support from Breadchain Co-operative (and beer from Raid Brood).

## Resources

- wiki.p2pfoundation.net/Ethereum_Localism
- pdxdao.xyz/localism
- mirror.xyz/ethpdx.eth
